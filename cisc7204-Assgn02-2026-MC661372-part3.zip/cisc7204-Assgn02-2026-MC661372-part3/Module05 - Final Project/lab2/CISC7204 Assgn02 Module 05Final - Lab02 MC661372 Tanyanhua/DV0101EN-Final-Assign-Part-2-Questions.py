import pandas as pd
import plotly.express as px
import dash
from dash import dcc, html
from dash.dependencies import Input, Output

# Load the dataset (Adjust the path if necessary)
df = pd.read_csv("https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/historical_automobile_sales.csv")

# Initialize the Dash app
app = dash.Dash(__name__)

# TASK 2.1: Create Dash application and give it a meaningful title
app.title = "Automobile Sales Statistics Dashboard"

# Get the list of years for the dropdown menu
year_list = [i for i in range(1980, 2024, 1)]

app.layout = html.Div([
    html.H1("Automobile Sales Statistics Dashboard",
            style={'textAlign': 'center', 'color': '#503D36', 'font-size': 24}),

    # TASK 2.2: Add drop-down menus to your dashboard with appropriate titles and options
    html.Div([
        # Dropdown for selecting the report type
        html.Label("Select Report Type:"),
        dcc.Dropdown(
            id='dropdown-statistics',
            options=[
                {'label': 'Yearly Statistics', 'value': 'Yearly Statistics'},
                {'label': 'Recession Period Statistics', 'value': 'Recession Period Statistics'}
            ],
            value='Yearly Statistics',
            placeholder='Select a report type',
            style={'width': '80%', 'padding': '3px', 'font-size': '20px', 'text-align-last': 'center'}
        ),

        # Dropdown for selecting the year
        html.Label("Select Year:"),
        dcc.Dropdown(
            id='select-year',
            options=[{'label': i, 'value': i} for i in year_list],
            value=2010,
            placeholder='Select a year',
            disabled=True,  # Initially disabled
            style={'width': '80%', 'padding': '3px', 'font-size': '20px', 'text-align-last': 'center'}
        )
    ], style={'padding': '10px'}),

    # TASK 2.3: Add a division for output display with appropriate id and classname property
    html.Div(id='output-container', className='chart-container',
             style={'display': 'flex', 'flex-wrap': 'wrap', 'justify-content': 'center'})
])

# TASK 2.4: Creating Callbacks; Define the callback function to update the input container based on the selected statistics
# Callback 1: Update the disabled state of the year dropdown based on the report type
@app.callback(
    Output(component_id='select-year', component_property='disabled'),
    Input(component_id='dropdown-statistics', component_property='value')
)
def update_input_container(selected_statistics):
    if selected_statistics == 'Yearly Statistics':
        return False
    else:
        return True


# Callback 2: Update the output container with charts based on the selected report type and year
@app.callback(
    Output(component_id='output-container', component_property='children'),
    [Input(component_id='dropdown-statistics', component_property='value'),
     Input(component_id='select-year', component_property='value')]
)
def update_output_container(selected_statistics, input_year):
    if selected_statistics == 'Recession Period Statistics':
        # Filter the data for recession periods (Recession == 1)
        recession_data = df[df['Recession'] == 1]

        # TASK 2.5: Create and display graphs for Recession Report Statistics
        # Plot 1 Automobile sales fluctuate over Recession Period (year wise) using line chart
        yearly_rec = recession_data.groupby('Year')['Automobile_Sales'].mean().reset_index()
        R_chart1 = dcc.Graph(
            figure=px.line(yearly_rec, x='Year', y='Automobile_Sales', title="Average Automobile Sales Fluctuation Over Recession Period (Year-wise)"))

        # Plot 2 Calculate the average number of vehicles sold by vehicle type and represent as a Bar chart
        avg_sales = recession_data.groupby('Vehicle_Type')['Automobile_Sales'].mean().reset_index()
        R_chart2 = dcc.Graph(
            figure=px.bar(avg_sales, x='Vehicle_Type', y='Automobile_Sales', title="Average Number of Vehicles Sold by Vehicle Type"))

        # Plot 3 : Pie chart for total expenditure share by vehicle type during recessions
        exp_rec = recession_data.groupby('Vehicle_Type')['Advertising_Expenditure'].sum().reset_index()
        R_chart3 = dcc.Graph(
            figure=px.pie(exp_rec, values='Advertising_Expenditure', names='Vehicle_Type', title="Total Expenditure Share by Vehicle Type During Recessions"))

        # Plot 4 Develop a Bar chart for the effect of unemployment rate on vehicle type and sales
        unemp_data = recession_data.groupby(['Vehicle_Type', 'unemployment_rate'])[
            'Automobile_Sales'].mean().reset_index()
        R_chart4 = dcc.Graph(
            figure=px.bar(unemp_data, x='Vehicle_Type', y='Automobile_Sales', color='unemployment_rate', title="Effect of Unemployment Rate on Vehicle Type and Sales"))
        return [
            html.Div(className='chart-item', children=[html.Div(children=R_chart1), html.Div(children=R_chart2)],style={'display': 'flex'}),
            html.Div(className='chart-item', children=[html.Div(children=R_chart3), html.Div(children=R_chart4)],style={'display': 'flex'})]

    # TASK 2.6: Create and display graphs for Yearly Report Statistics
    elif (selected_statistics == 'Yearly Statistics') and input_year:
        # Filter the data for the selected year
        yearly_data = df[df['Year'] == int(input_year)]

        # Plot 1 :Yearly Automobile sales using line chart for the whole period.
        yearly_total_sales = df.groupby('Year')['Automobile_Sales'].mean().reset_index()
        Y_chart1 = dcc.Graph(
            figure=px.line(yearly_total_sales, x='Year', y='Automobile_Sales', title="Yearly Automobile Sales Using Line Chart for the Whole Period"))

        # Plot 2 :Total Monthly Automobile sales using line chart.
        monthly_sales = yearly_data.groupby('Month')['Automobile_Sales'].sum().reset_index()
        Y_chart2 = dcc.Graph(
            figure=px.line(monthly_sales, x='Month', y='Automobile_Sales', title="Total Monthly Automobile Sales"))

        # Plot bar chart for average number of vehicles sold during the given year
        avg_yearly_sales = yearly_data.groupby('Vehicle_Type')['Automobile_Sales'].mean().reset_index()
        Y_chart3 = dcc.Graph(
            figure=px.bar(avg_yearly_sales, x='Vehicle_Type', y='Automobile_Sales', title="Average Vehicles Sold by Vehicle Type in the Selected Year"))

        # Plot 4 Total Advertisement Expenditure for each vehicle using pie chart
        yearly_adv_type = yearly_data.groupby('Vehicle_Type')['Advertising_Expenditure'].sum().reset_index()
        Y_chart4 = dcc.Graph(
            figure=px.pie(yearly_adv_type, values='Advertising_Expenditure', names='Vehicle_Type', title="Total Advertisement Expenditure for Each Vehicle"))

        return [
            html.Div(className='chart-item', children=[html.Div(children=Y_chart1), html.Div(children=Y_chart2)],style={'display': 'flex'}),
            html.Div(className='chart-item', children=[html.Div(children=Y_chart3), html.Div(children=Y_chart4)],style={'display': 'flex'})]

    else:
        return None

# Run the application
if __name__ == '__main__':
    app.run()